package com.example.kuldeep.readcontacts;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import static android.Manifest.permission.READ_CONTACTS;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_READ_CONTACTS = 444;
    private ProgressDialog pDialog;
    private Handler updateBarHandler;
    List<contactList> contactList;
    int counter;
    RecyclerView rvContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pDialog = new ProgressDialog(MainActivity.this);
        pDialog.setMessage("Reading contacts...");
        pDialog.setCancelable(false);
        pDialog.show();
        rvContact=findViewById(R.id.rvContact);
        updateBarHandler = new Handler();

        // Since reading contacts takes more time, let's run it on a separate thread.
        new Thread(new Runnable() {
            @Override
            public void run() {
                readContacts();
            }
        }).start();

    }
    private boolean mayRequestContacts() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (checkSelfPermission(READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        if (shouldShowRequestPermissionRationale(READ_CONTACTS)) {
            requestPermissions(new String[]{READ_CONTACTS}, REQUEST_READ_CONTACTS);
        } else {
            requestPermissions(new String[]{READ_CONTACTS}, REQUEST_READ_CONTACTS);
        }
        return false;
    }
    /**
     * Callback received when a permissions request has been completed.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        if (requestCode == REQUEST_READ_CONTACTS) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                readContacts();
            }
        }
    }

    public void readContacts() {
        if (!mayRequestContacts()) {
            return;
        }
        contactList  = new ArrayList();
        ContentResolver cr = getContentResolver();
        final Cursor cur = getContentResolver().query(
                ContactsContract.Contacts.CONTENT_URI,
                null, null, null,
                ContactsContract.Contacts.SORT_KEY_PRIMARY + " ASC");
        String phone = null;

        if (cur.getCount() > 0) {

            while (cur.moveToNext()) {
                String id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                updateBarHandler.post(new Runnable() {
                    public void run() {
                        pDialog.setMessage("Reading contacts : " + counter++ + "/" + cur.getCount());
                    }
                });
                if (Integer.parseInt(cur.getString(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {


                    Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        phone = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));


                    }
                    pCur.close();

                    if((phone!=null) && !phone.equals(""))
                    {
                        contactList obj=new contactList();
                        //if (contactList.get())
                        phone=phone.replaceAll("\\s+","");
                        if(phone.startsWith("+"))
                        {
                            if(phone.length()==13)
                            {
                                String str_getMOBILE=phone.substring(3);
                                obj.setName(name.toString());
                                obj.setPhone(str_getMOBILE.toString());
                            }
                            else if(phone.length()==14)
                            {
                                String str_getMOBILE=phone.substring(4);

                                obj.setName(name.toString());
                                obj.setPhone(str_getMOBILE.toString());
                            }
                        }
                        else
                        {
                           // contactMn_etMobile.setText(phoneNo);
                            obj.setName(name.toString());
                            obj.setPhone(phone.toString());
                        }

                        contactList.add(obj);
                    }
                }
             //   contactList.add(sb.toString());
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AllContactsAdapter contactAdapter = new AllContactsAdapter(getApplicationContext(),contactList);
                    rvContact.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    rvContact.setAdapter(contactAdapter);

                }
            });
            // Dismiss the progressbar after 500 millisecondds
            updateBarHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    pDialog.cancel();
                }
            }, 500);

        }
    }

}
